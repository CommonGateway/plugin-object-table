jQuery(document).ready(function($) {
    // Event listener for the header click
    $('th').on('click', function() {
        var headerId = $(this).attr('id'); // Get the header id
        var matches = headerId.match(/table(\d+)Header_/); // Use a regex to extract the configId
        if (matches) {
            $('html, body').css({'cursor' : 'wait'});
            var configId = matches[1]; // The first captured group is the configId
            var column = headerId.replace('table' + configId + 'Header_', ''); // Get the column to sort by
            var order = $(this).hasClass('asc') ? 'desc' : 'asc'; // Toggle sort order
            
            // Make an AJAX request to the server
            $.ajax({
                url: '/wp-admin/admin-ajax.php', // WordPress AJAX
                type: 'POST',
                data: {
                    action: 'object_handle_sort', // The WP AJAX action hook
                    sort_column: column,
                    sort_order: order,
                    config_id: configId // Pass the configId to your AJAX handler
                },
                success: function(data) {
                    // Assuming 'data' is the HTML for the new table rows
                    $('#objectTable' + configId  + ' tbody').empty(); // Update the table body
                    $('#objectTable' + configId  + ' tbody').html(data.data.html); // Update the table body
                    $('th').removeClass('asc desc'); // Reset the classes
                    $('#table' + configId + 'Header_' + column).addClass(order); // Add the class to the current header
                },
                complete: function() {
                    $('html, body').css({'cursor' : 'default'});
                }
            });
        }
    });
});


